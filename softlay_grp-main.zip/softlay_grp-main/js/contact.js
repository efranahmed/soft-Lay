$(document).ready(function(){
    $('#hide').click(function(){
        $('.one').toggle()
    })
})